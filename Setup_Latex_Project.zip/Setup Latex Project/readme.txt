1) open the terminal
2) run the following command:
   sh latex_maker_setup.sh
3) now you have 2 options in order to see the results:
   i) log out and log in
   ii) in the terminal run:
       source $HOME/.bashrc
